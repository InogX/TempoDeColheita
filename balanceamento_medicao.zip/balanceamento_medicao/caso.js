// Acompanha UMA partida com objetivo isolado e mostra a evolução de P0 (e o motivo de eliminação). Uso: node caso.js "Objetivo 12" [n] [semente]
const { novo } = require('./carrega.js'); const id = process.argv[2], n = +process.argv[3] || 2, sem = +process.argv[4] || 1;
const J = novo(sem, process.env.PASTA ? process.env.PASTA.replace(/\/?$/, '/') : undefined);
J.v(`function __caso(id, n) { const bots = Array(n).fill('normal'); A.new({ nomes: bots.map((_, i) => 'P' + i), bots, first: 0 });
  S.players[0].obj = { ...CARDS.objetivo.find(c => c.id === id) }; for (let i = 1; i < n; i++) S.players[i].obj = { id: 'Nunca', t: 'nunca' };
  Bot.chave = ''; const tr = []; let ult = -1, passos = 0;
  while (S && !S.win && S.round <= 60 && passos++ < 400000) { if (S.round !== ult) { ult = S.round; const p = S.players[0], q = S.players[1]; tr.push([S.round, p.coins, p.debt, S.gov, q.coins, p.fields.length, plotsOf(p).length, plotsOf(p).reduce((a, x) => a + lvOf(x), 0), K.reduce((a, k) => a + (p.res[k] || 0), 0), S.mk.length, p.st.mb || 0, p.st.mp || 0, p.out ? 1 : 0, S.ev.map(e => e.c.nome).join('+')]); } Bot.acao(); }
  return { tr, log: S.log.slice(), win: S.win, out: S.players.map(p => p.out), r: S.round }; }`);
const r = J.v(`__caso(${JSON.stringify(id)}, ${n})`);
console.log('rod  P0coins P0div  cofre  P1coins  campos plantios níveis estoque ofertas  compras lucroMkt out evento'); r.tr.forEach(t => console.log(t.map((x, i) => String(x).padStart(i === 13 ? 0 : 7)).join(' ')));
console.log('final:', JSON.stringify({ win: r.win, out: r.out, rodada: r.r })); console.log(r.log.join('\n'));
