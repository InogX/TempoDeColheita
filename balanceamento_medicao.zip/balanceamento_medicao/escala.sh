#!/bin/bash
for spec in "Objetivo 6:v:6000" "Objetivo 7:v:4000" "Objetivo 8:v:3000" "Objetivo 18:v:2000" "Objetivo 19:v:2500"; do
  IFS=: read id campo base <<< "$spec"
  echo "######## $id ($campo base $base): meta = base x n/5"
  for n in 2 3 4 5; do
    val=$(python3 -c "print(round($base*$n/5))")
    printf "n=%s meta=%-5s " $n $val
    node ajuste.js "$id" $campo $n "$val" 60 | tail -1
  done
done
