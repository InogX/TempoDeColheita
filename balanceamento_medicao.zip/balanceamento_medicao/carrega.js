// Carrega o jogo REAL (sem tela, sem rede) num contexto isolado do Node para medir o balanceamento. Sorteio reprodutível (semente).
const vm = require('vm'), fs = require('fs'), dir = __dirname + '/';
const ARQ = ['cartas.js', 'config.js', 'estado.js', 'cartas-visual.js', 'consultas.js', 'objetivos.js', 'rodada.js', 'acoes-turno.js', 'acoes-economia.js', 'acoes-plantio.js', 'acoes-mercado.js', 'comandos.js', 'bot.js', 'dev.js']; // a mesma ordem do index.html (só o que roda sem tela)
function novo(semente = 1, pasta = dir) {
  const sb = { console, setTimeout, clearTimeout, localStorage: { getItem: () => null, setItem() {}, removeItem() {} }, alert() {}, confirm: () => true };
  sb.window = sb; sb.document = { getElementById: () => null, querySelectorAll: () => [], querySelector: () => null, addEventListener() {}, createElement: () => ({}) }; sb.matchMedia = () => ({ matches: false }); sb.addEventListener = () => {};
  vm.createContext(sb);
  vm.runInContext(`function render() {}; function menu() {}; let __s = ${semente >>> 0}; Math.random = () => { __s = (__s + 0x6D2B79F5) >>> 0; let t = __s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };`, sb);
  ARQ.forEach(f => vm.runInContext(fs.readFileSync(pasta + f, 'utf8'), sb, { filename: f }));
  if (process.env.PRE) vm.runInContext(process.env.PRE, sb); // ajuste opcional feito DEPOIS de carregar (ex.: PRE='ASSETS.niveis[2].evolucao=150')
  return { v: c => vm.runInContext(c, sb), sb };
}
module.exports = { novo };
