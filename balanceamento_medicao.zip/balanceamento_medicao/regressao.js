// Verificação de segurança do jogo REAL (pasta dada): partidas só de bots em vários tamanhos + textos dos objetivos. Uso: node regressao.js [pasta]
const { novo } = require('./carrega.js'); const pasta = process.argv[2] ? process.argv[2].replace(/\/?$/, '/') : undefined; const J = novo(2026, pasta);
let ruins = 0; const ok = (c, m) => { if (!c) { ruins++; console.log('  ✗ ' + m); } };
for (const [n, niveis] of [[2, ['normal']], [2, ['normal', 'facil']], [3, ['normal', 'facil']], [4, ['normal']], [6, ['normal', 'facil']], [10, ['normal']]]) {
  const rel = J.v(`(() => { const lg = console.log; console.log = () => {}; try { return Bot.simular(150, ${n}, ${JSON.stringify(niveis)}); } finally { console.log = lg; } })()`);
  const nErr = Object.keys(rel.erros).length; ok(nErr === 0, `${n} jogadores ${niveis}: erros ${JSON.stringify(rel.erros)}`); ok(rel.terminaram + rel.semFim === 150, 'contagem de partidas');
  console.log(`${n} jogadores ${niveis.join('/')}: terminaram ${rel.terminaram}/150, sem fim ${rel.semFim}, eliminados ${rel.eliminados}, rodadas (média) ${rel.rodadasMedia}, erros ${nErr}`); }
for (const n of [2, 3, 4, 5, 6, 10]) { J.v(`A.new({ nomes: ${JSON.stringify(Array.from({ length: n }, (_, i) => 'P' + i))}, bots: ${JSON.stringify(Array(n).fill('normal'))}, first: 0 })`);
  const txt = J.v('CARDS.objetivo.map(o => [o.id, desc(o), vef(o)])'); txt.forEach(([id, d, v]) => { ok(!/undefined|NaN|\{|\}/.test(d), `${n}p ${id}: texto estranho: ${d}`); ok(Number.isFinite(v) && v >= 1, `${n}p ${id}: meta efetiva inválida ${v}`); }); }
J.v('S = null'); const t0 = J.v('CARDS.objetivo.map(o => objTxt(o))'); ok(t0.every(t => !/undefined|NaN/.test(t)), 'textos sem partida (menu/editor) sem undefined/NaN');
console.log(ruins ? `\n✗ ${ruins} problema(s)` : '\n✓ sem erros nas partidas de bots e textos de objetivos corretos (2 a 10 jogadores)');
if (process.argv[3] === '--textos') { J.v(`A.new({ nomes: ['A','B'], bots: ['normal','normal'], first: 0 })`); console.log(J.v('CARDS.objetivo.map(o => o.t.padEnd(10) + desc(o)).join("\\n")')); }
process.exit(ruins ? 1 : 0);
