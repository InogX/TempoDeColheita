// Reproduz o que o editor.html faz (abrir -> migrate -> salvar) com os arquivos do jogo da pasta dada e confere se nada se perde. Uso: node teste_editor.js final
const fs = require('fs'), dir = process.argv[2].replace(/\/?$/, '/'); let ruins = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) ruins++; };
const cfg = fs.readFileSync(dir + 'config.js', 'utf8'), t = fs.readFileSync(dir + 'cartas.js', 'utf8');
const cru = new Function(cfg + ';' + t + ';return{CARDS,ASSETS}')();                                    // cartas.js como está no arquivo
const o = new Function(cfg + ';' + t + ';migrate(CARDS,ASSETS);return{CARDS,ASSETS}')();               // o que o editor carrega
const data = o.CARDS, assets = o.ASSETS;
ok(JSON.stringify(cru) === JSON.stringify(o), 'ao abrir, o migrate() NÃO altera nada (os dados do arquivo já estão completos)');
const out = '// ARQUIVO DE DADOS - editado pelo editor.html (ou à mão, se preferir)\nconst CARDS = {\n' + Object.entries(data).map(([k, a]) => ` "${k}": [\n` + a.map(c => '  ' + JSON.stringify(c)).join(',\n') + '\n ]').join(',\n') + '\n};\nconst ASSETS = ' + JSON.stringify(assets, null, 1) + ';\n'; // igual ao botão Salvar
const volta = new Function(out + ';return{CARDS,ASSETS}')();
ok(JSON.stringify(volta) === JSON.stringify(o), 'abrir -> salvar -> reler: os dados são IDÊNTICOS (nenhum campo se perde: minJ, v, n, r, v2, floor, elim, esc...)');
const ob = id => volta.CARDS.objetivo.find(c => c.id === id);
ok([14, 15, 12, 13].every(i => ob('Objetivo ' + i).minJ >= 6) && ob('Objetivo 14').minJ === 6 && ob('Objetivo 15').minJ === 6 && ob('Objetivo 12').minJ === 99 && ob('Objetivo 13').minJ === 99, 'minJ preservado: mAll/mSellTo = 6; mBuys/mProfit = 99 (desligados)');
ok(ob('Objetivo 20').t === 'allLvl' && ob('Objetivo 20').v === 10 && ob('Objetivo 1').v === 1, 'allLvl = 10 plantios; lvl3n = 1');
const ids = volta.CARDS.objetivo.map(c => c.id); ok(ids.length === 20 && new Set(ids).size === 20, 'os 20 objetivos continuam lá, sem duplicata');
ok(volta.ASSETS.deckVersion === 5, 'deckVersion 5 mantido (o migrate não reinicia baralhos)');
ok(/allLvl.*Tenha \{v\}\+ plantios/.test(cfg), 'config.js (texto dos objetivos, que o editor NÃO edita) tem o texto novo do allLvl');
const campos = new Set(); volta.CARDS.objetivo.forEach(c => Object.entries(c).forEach(([k, v]) => { if (typeof v === 'number') campos.add(k); }));
console.log('  campos numéricos de objetivo que o editor mostra como caixa de edição: ' + [...campos].join(', '));
process.exit(ruins ? 1 : 0);
