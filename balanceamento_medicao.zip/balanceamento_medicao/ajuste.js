// Curva de dificuldade: varia UM campo de UM objetivo e mede (isolado, n jogadores). Uso: node ajuste.js "Objetivo 6" v 2 "1000,1500,2000" [N] [--bot=allLvl] [pasta]
const { novo } = require('./carrega.js'); const [id, campo, nS, lista] = process.argv.slice(2, 6), N = +process.argv[6] || 100, extra = process.argv.slice(7);
const n = +nS, valores = lista.split(',').map(Number), patch = (extra.find(a => a.startsWith('--bot=')) || '').slice(6), pasta = (extra.find(a => !a.startsWith('--')) || '').replace(/\/?$/, '/') || undefined;
const J = novo(999, pasta && pasta !== '/' ? pasta : undefined);
if (patch === 'allLvl') J.v(`(() => { const pl = Bot.plantio.bind(Bot), mc = Bot.melhorCampo.bind(Bot); // SÓ NO TESTE: com allLvl, para de plantar/comprar campo ao chegar na meta de plantios (um humano faria isso)
  Bot.plantio = function (p) { if (p.obj.t === 'allLvl' && plotsOf(p).length >= p.obj.n) return null; return pl(p); };
  Bot.melhorCampo = function (p) { if (p.obj.t === 'allLvl' && plotsOf(p).length >= p.obj.n) return null; return mc(p); }; })()`);
if (patch === 'allLvl2') J.v(`(() => { const pl = Bot.plantio.bind(Bot), mc = Bot.melhorCampo.bind(Bot); // SÓ NO TESTE: plantar só em campo de 2+ vagas (nível 2 ocupa 2 vagas) e só até a meta de plantios
  Bot.plantio = function (p) { if (p.obj.t !== 'allLvl') return pl(p); if (plotsOf(p).length >= p.obj.n) return null; const fs = p.fields.filter(f => f.c.slots >= 2 && free(f) >= 1); if (!fs.length) return null; const hand = p.hand.findIndex(c => fs.some(f => fits(f, c))); if (hand < 0) return null; const f = fs.find(f => fits(f, p.hand[hand])); return { h: hand, fi: p.fields.indexOf(f), s: 9 }; };
  Bot.melhorCampo = function (p) { if (p.obj.t !== 'allLvl') return mc(p); if (p.fields.filter(f => f.c.slots >= 2).length >= p.obj.n) return null; if ((p.compras || 0) >= REG.maxCompraCamposPorTurno) return null; let best = null; S.center.forEach((c, i) => { if (c.slots < 2) return; const pr = buyPrice(p, c); if (p.coins - pr < 120) return; if (!best || pr < best.pr) best = { i, s: 9, pr }; }); return best; }; })()`);
J.v(`function __ja(id, n, maxR, first) { const bots = Array(n).fill('normal'); A.new({ nomes: bots.map((_, i) => 'P' + i), bots, first });
  S.players[0].obj = { ...CARDS.objetivo.find(c => c.id === id) }; for (let i = 1; i < n; i++) S.players[i].obj = { id: 'Nunca', t: 'nunca' };
  Bot.chave = ''; Bot.erros = 0; let passos = 0; while (S && !S.win && S.round <= maxR && passos++ < 400000) Bot.acao();
  return { w: S.win ? S.players.findIndex(p => p.n === S.win.n) : -1, round: S.round, out: S.players[0].out }; }`);
const med = a => a.length ? a.slice().sort((x, y) => x - y)[Math.floor(a.length / 2)] : '-', p90 = a => a.length ? a.slice().sort((x, y) => x - y)[Math.min(a.length - 1, Math.floor(a.length * 0.9))] : '-';
console.log(`${id}: variando "${campo}", ${n} jogadores, ${N} partidas cada${patch ? ', bot corrigido só no teste: ' + patch : ''}\n  valor  cumpriu  elim  semFim  rodada(med / p90)`);
for (const v of valores) { J.v(`CARDS.objetivo.find(c => c.id === ${JSON.stringify(id)}).${campo} = ${v}`); let ok = 0, el = 0, sf = 0; const ro = [];
  for (let g = 0; g < N; g++) { const r = J.v(`__ja(${JSON.stringify(id)}, ${n}, 150, ${g % n})`); if (r.w === 0) { ok++; ro.push(r.round); } else if (r.out) el++; else sf++; }
  console.log(`${String(v).padStart(7)} ${(100 * ok / N).toFixed(0).padStart(7)}% ${(100 * el / N).toFixed(0).padStart(4)}% ${(100 * sf / N).toFixed(0).padStart(6)}%  ${String(med(ro)).padStart(6)} / ${p90(ro)}`); }
