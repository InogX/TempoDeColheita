# Medição de balanceamento (Node) — Tempo de Colheita

Roda o **jogo real** sem tela e sem rede, só com bots, para medir o balanceamento. **Não faz parte do jogo** e não vai para o GitHub Pages.

## Preparo
Ponha estes scripts **na mesma pasta** dos arquivos do jogo: `cartas.js`, `config.js`, `estado.js`, `cartas-visual.js`, `consultas.js`, `objetivos.js`, `rodada.js`, `acoes-turno.js`, `acoes-economia.js`, `acoes-plantio.js`, `acoes-mercado.js`, `comandos.js`, `bot.js`, `dev.js`. (Ou passe a pasta como último argumento nos scripts que aceitam.) O sorteio é reprodutível (semente fixa).

## Scripts
| Comando | Para quê |
|---|---|
| `node medir.js natural 300 [pasta]` | 3000 partidas de 2 bots com objetivos sorteados: quanto cada objetivo venceu. `NJOG=5 node medir.js ...` muda o nº de jogadores. |
| `node medir.js solo 100 [pasta]` | Cada objetivo **isolado** (o adversário tem um objetivo que nunca fecha): % que cumpre e mediana de rodadas. É a medida de dificuldade. |
| `node solo_n.js 100 "Objetivo 6,Objetivo 7" [pasta]` | O mesmo, para 2, 3, 4 e 5 jogadores. |
| `node ajuste.js "Objetivo 6" v 2 "1000,1500,2000" 100 [pasta]` | Curva de dificuldade: varia UM número de UM objetivo. `--bot=allLvl2` aplica um bot ajustado só no teste. |
| `node par.js "Objetivo 13" mBuys 100 v=600` | Objetivo de mercado com um parceiro cooperativo. |
| `node caso.js "Objetivo 12" 2 3` | Acompanha UMA partida, rodada a rodada (moedas, cofre, plantios...). |
| `node traj.js "" 2 60 150` | Trajetória do dinheiro total (moedas + cofre) por rodada. |
| `node regressao.js [pasta] [--textos]` | Verificação de segurança: partidas de bots de 2 a 10 jogadores (fácil e normal) sem erros + textos dos objetivos. **Rode depois de qualquer mudança em cartas/objetivos.** |
| `PRE='ASSETS.niveis[2].evolucao=150' node ajuste.js ...` | Altera uma regra depois de carregar, sem editar arquivo (experimentos). |

## Limites
Bot não é humano: um objetivo que o bot não cumpre pode ser cumprível por uma pessoa (e vice-versa). Os números dizem **como as regras se comportam com estes bots**.
