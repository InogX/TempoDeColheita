# Medição de balanceamento — Tempo de Colheita

## O que é isto, em poucas palavras
Um conjunto de scripts que **joga o seu jogo sozinho milhares de vezes** (só bots, sem tela, sem internet) e conta o que acontece: quais objetivos ganham mais, quanto tempo leva para cumprir cada um, e se aparece algum erro. Serve para **ajustar números com base em dados** em vez de achismo.

## Você precisa rodar isto?
**Normalmente não.** Quem roda sou eu, nas conversas em que ajustamos o balanceamento. O que você precisa fazer é só **guardar este zip** e enviá-lo junto com os arquivos do jogo quando quiser rebalancear. Rodar por conta própria é opcional.

## Se quiser rodar sozinho (uma vez, ~1 minuto)
1. Instale o **Node.js** (nodejs.org, versão LTS). Não precisa configurar nada.
2. Descompacte este zip e **copie para a mesma pasta** os arquivos do jogo: `cartas.js`, `config.js`, `estado.js`, `cartas-visual.js`, `consultas.js`, `objetivos.js`, `rodada.js`, `acoes-turno.js`, `acoes-economia.js`, `acoes-plantio.js`, `acoes-mercado.js`, `comandos.js`, `bot.js`, `dev.js`.
3. Abra um terminal **nessa pasta** (no Windows: clique na barra de endereço da pasta, digite `cmd` e Enter).
4. Digite: `node medir_tudo.js` e Enter.
5. Espere. Ele explica na tela o que cada bloco significa.

## Como ler o resultado (o essencial)
- **Bloco 1 (segurança):** todas as linhas com `erros 0` e um `✓` no final = nada quebrou.
- **Bloco 2 (partidas de verdade):** a coluna `%venceu` mostra a chance de cada objetivo. Valores muito diferentes entre si indicam desequilíbrio. Também mostra a duração típica da partida em rodadas.
- **Bloco 3 (objetivo sozinho):** `cumpriu` deve ser ~100% e `rodada(mediana)` parecida entre os objetivos.
- **Importante:** bot não é humano. Um número ruim pode ser limitação do bot, e não da regra (já aconteceu com o `allLvl`). Os números dizem **como as regras se comportam com estes bots**.

## Quando rodar de novo
Sempre que mudar números de objetivos/regras ou o bot (para ver o efeito) e depois de qualquer mudança em `cartas.js`, `objetivos.js`, `cartas-visual.js` ou `bot.js`.

---
## Referência técnica (comandos avulsos)
| Comando | Para quê |
|---|---|
| `node medir_tudo.js` | Os três blocos acima. |
| `node regressao.js [pasta] [--textos]` | Só a verificação de segurança (partidas de bots de 2 a 10 jogadores + textos dos objetivos). |
| `node medir.js natural 300 [pasta]` | 3000 partidas de 2 bots, objetivos sorteados. `NJOG=6 node medir.js ...` muda o nº de jogadores. |
| `node medir.js solo 100 [pasta]` | Cada objetivo isolado. |
| `node solo_n.js 100 "Objetivo 6,Objetivo 7" [pasta]` | O mesmo para 2, 3, 4 e 5 jogadores. |
| `node ajuste.js "Objetivo 6" v 2 "1000,1500,2000" 100 [pasta]` | Curva de dificuldade: varia UM número de UM objetivo (2 = jogadores). |
| `node par.js "Objetivo 11" mBuys 100 v=16` | Objetivo de mercado com um parceiro cooperativo. |
| `node caso.js "Objetivo 20" 2 5` | Acompanha UMA partida rodada a rodada (use `PASTA=pasta` para outra pasta). |
| `node traj.js "" 2 60 150` | Trajetória do dinheiro total (moedas + cofre) por rodada. |
| `node teste_editor.js pasta` | Simula abrir/salvar do `editor.html` e confere que nenhum dado se perde. |
| `PRE='código' node ajuste.js ...` | Muda uma regra depois de carregar, sem editar arquivo (experimentos). |

O sorteio é reprodutível (semente fixa): as mesmas medidas dão os mesmos números.
