// Trajetória do dinheiro: coins dos jogadores + cofre do Governo, por rodada (média de várias partidas), e uma partida exemplo.
const { novo } = require('./carrega.js'); const id = process.argv[2] || null, n = +process.argv[3] || 2, R = +process.argv[4] || 60, G = +process.argv[5] || 100;
const J = novo(777);
J.v(`function __traj(id, n, R) { const bots = Array(n).fill('normal'); A.new({ nomes: bots.map((_, i) => 'P' + i), bots, first: 0 });
  if (id) { S.players[0].obj = { ...CARDS.objetivo.find(c => c.id === id) }; for (let i = 1; i < n; i++) S.players[i].obj = { id: 'Nunca', t: 'nunca' }; }
  Bot.chave = ''; const tr = []; let ult = -1, passos = 0;
  while (S && !S.win && S.round <= R && passos++ < 400000) { if (S.round !== ult) { ult = S.round; tr.push({ r: S.round, c: S.players.map(p => p.coins), d: S.players.map(p => p.debt), g: S.gov, out: S.players.map(p => p.out) }); } Bot.acao(); }
  return tr; }`);
const soma = Array(R + 1).fill(0), cont = Array(R + 1).fill(0), gv = Array(R + 1).fill(0), c0 = Array(R + 1).fill(0);
for (let g = 0; g < G; g++) { const tr = J.v(`__traj(${JSON.stringify(id)}, ${n}, ${R})`); tr.forEach(t => { if (t.r > R) return; soma[t.r] += t.c.reduce((a, b) => a + b, 0) + t.g; gv[t.r] += t.g; c0[t.r] += t.c[0]; cont[t.r]++; }); }
console.log(`objetivo do jogador 0: ${id || '(sorteado)'}, ${n} jogadores, ${G} partidas. Dinheiro TOTAL = moedas de todos + cofre. Início: ${500 * n} + ${1000 * n} = ${1500 * n}`);
console.log('rodada   total(méd)  cofre(méd)  moedas do P0(méd)  partidas ativas');
[1, 2, 3, 5, 8, 10, 15, 20, 30, 40, 50, 60].filter(r => r <= R && cont[r]).forEach(r => console.log(`${String(r).padStart(6)} ${(soma[r] / cont[r]).toFixed(0).padStart(11)} ${(gv[r] / cont[r]).toFixed(0).padStart(11)} ${(c0[r] / cont[r]).toFixed(0).padStart(18)} ${String(cont[r]).padStart(16)}`));
