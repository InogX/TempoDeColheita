// Medições de balanceamento (2 jogadores) com o jogo REAL. Uso: node medir.js [natural|solo|tudo] [N] [pasta-do-jogo]
const { novo } = require('./carrega.js');
const modo = process.argv[2] || 'tudo', N = +process.argv[3] || 200, pasta = process.argv[4] ? process.argv[4].replace(/\/?$/, '/') : undefined;
const J = novo(12345, pasta);
J.v(`function __jogo(id, maxR, first, niveis) { const NJOG = ${process.env.NJOG || 2}; const bots = Array.from({ length: NJOG }, (_, i) => niveis[i % niveis.length]);
  A.new({ nomes: bots.map((_, i) => 'P' + i), bots, first });
  if (id) { S.players[0].obj = { ...CARDS.objetivo.find(c => c.id === id) }; for (let i = 1; i < NJOG; i++) S.players[i].obj = { id: 'Nunca', t: 'nunca' }; }
  Bot.chave = ''; Bot.erros = 0; let passos = 0; const c0 = S.players.map(p => p.obj.id);
  while (S && !S.win && S.round <= maxR && passos++ < 400000) Bot.acao();
  const w = S.win ? S.players.findIndex(p => p.n === S.win.n) : -1;
  return { w, why: S.win ? S.win.why : '', round: S.round, obj: c0, tipo: S.players.map(p => p.obj.t), out: S.players.map(p => p.out), coins: S.players.map(p => p.coins), debt: S.players.map(p => p.debt), gov: S.gov, loans: S.players.map(p => p.st.loans || 0), fields: S.players.map(p => p.fields.length), niv: S.players.map(p => plotsOf(p).reduce((a, x) => a + lvOf(x), 0)), done: S.players.map(p => !!done(p)) }; }`);
const jogo = (id, maxR, first, niveis) => J.v(`__jogo(${JSON.stringify(id)}, ${maxR}, ${first}, ${JSON.stringify(niveis)})`);
const med = a => { if (!a.length) return '-'; const s = a.slice().sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
const p90 = a => { if (!a.length) return '-'; const s = a.slice().sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(s.length * 0.9))]; };
const OBJ = J.v('CARDS.objetivo.map(o => [o.id, o.t])');
if (modo === 'natural' || modo === 'tudo') {
  const por = {}; let fim = 0, semFim = 0, ro = [], elimGeral = 0; const t0 = Date.now();
  for (let g = 0; g < N * 10; g++) { const r = jogo(null, 150, g % (+process.env.NJOG || 2), ['normal']);
    r.tipo.forEach((t, i) => { const o = por[t] = por[t] || { sorteado: 0, venceu: 0, elim: 0 }; o.sorteado++; if (r.w === i) o.venceu++; if (r.out[i]) o.elim++; });
    if (r.w >= 0) { fim++; ro.push(r.round); } else semFim++; }
  console.log(`\n== NATURAL: ${N * 10} partidas, 2 bots normais, objetivos sorteados (${((Date.now() - t0) / 1000).toFixed(0)} s) ==`);
  console.log(`terminaram ${fim}, sem fim em 150 rodadas ${semFim}; rodadas: mediana ${med(ro)}, p90 ${p90(ro)}`);
  console.log('objetivo      sorteado  venceu  %venceu  eliminado');
  Object.entries(por).sort((a, b) => b[1].venceu / b[1].sorteado - a[1].venceu / a[1].sorteado).forEach(([t, o]) => console.log(`${t.padEnd(12)} ${String(o.sorteado).padStart(8)} ${String(o.venceu).padStart(7)} ${(100 * o.venceu / o.sorteado).toFixed(0).padStart(7)}% ${String(o.elim).padStart(9)}`));
}
if (modo === 'solo' || modo === 'tudo') {
  console.log(`\n== ISOLADO: ${N} partidas por objetivo; o outro jogador tem um objetivo que nunca fecha (maxRodadas 150) ==`);
  console.log('objetivo     tipo         cumpriu  elim  semFim  rodada(mediana/p90)  | sobra do cofre  moedas fim(med)');
  for (const [id, t] of OBJ) { let ok = 0, el = 0, sf = 0; const ro = [], gv = [], mo = [];
    for (let g = 0; g < N; g++) { const r = jogo(id, 150, g % 2, ['normal']); if (r.w === 0) { ok++; ro.push(r.round); } else if (r.out[0]) el++; else sf++; gv.push(r.gov); mo.push(r.coins[0]); }
    console.log(`${id.padEnd(12)} ${t.padEnd(11)} ${(100 * ok / N).toFixed(0).padStart(6)}% ${(100 * el / N).toFixed(0).padStart(4)}% ${(100 * sf / N).toFixed(0).padStart(6)}%  ${String(med(ro)).padStart(8)} / ${String(p90(ro)).padEnd(6)}       | ${String(med(gv)).padStart(8)}  ${String(med(mo)).padStart(10)}`); }
}
