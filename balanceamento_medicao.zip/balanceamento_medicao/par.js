// Objetivo de mercado com PARCEIRO cooperativo (n=2): P1 tem um objetivo de mercado que nunca fecha (v enorme), então negocia como um jogador de mercado.
// Uso: node par.js "Objetivo 12" "mSales" [N] [campo=valor ...]   (P0 = objetivo; P1 = tipo de mercado inalcançável: mSales (vende) | mBuys (compra))
const { novo } = require('./carrega.js'); const [id, tipoP1] = process.argv.slice(2, 4), N = +process.argv[4] || 100, ajustes = process.argv.slice(5);
const J = novo(31337); ajustes.forEach(a => { const [k, v] = a.split('='); J.v(`CARDS.objetivo.find(c => c.id === ${JSON.stringify(id)}).${k} = ${+v}`); });
J.v(`function __par(id, t1, maxR, first) { A.new({ nomes: ['A', 'B'], bots: ['normal', 'normal'], first });
  S.players[0].obj = { ...CARDS.objetivo.find(c => c.id === id) }; S.players[1].obj = { id: 'Parceiro', t: t1, v: 99999, esc: 1 };
  Bot.chave = ''; Bot.erros = 0; let passos = 0; while (S && !S.win && S.round <= maxR && passos++ < 400000) Bot.acao();
  return { w: S.win ? S.players.findIndex(p => p.n === S.win.n) : -1, round: S.round, out: S.players[0].out, mb: S.players[0].st.mb || 0, ms: S.players[0].st.ms || 0, mp: S.players[0].st.mp || 0, mu: S.players[0].st.mu || 0 }; }`);
let ok = 0, el = 0, sf = 0; const ro = [], extra = []; const med = a => a.length ? a.slice().sort((x, y) => x - y)[Math.floor(a.length / 2)] : '-';
for (let g = 0; g < N; g++) { const r = J.v(`__par(${JSON.stringify(id)}, ${JSON.stringify(tipoP1)}, 150, ${g % 2})`); if (r.w === 0) { ok++; ro.push(r.round); } else if (r.out) el++; else sf++; extra.push([r.mb, r.ms, r.mp, r.mu]); }
const m = i => med(extra.map(e => e[i]));
console.log(`${id} vs parceiro "${tipoP1}" ${ajustes.join(' ')}: cumpriu ${(100 * ok / N).toFixed(0)}%  elim ${(100 * el / N).toFixed(0)}%  semFim ${(100 * sf / N).toFixed(0)}%  rodada(med) ${med(ro)}   [fim: compras ${m(0)}, vendas ${m(1)}, lucro ${m(2)}, unidades ${m(3)}]`);
