// Objetivo isolado com n jogadores (os outros n-1 têm objetivo que nunca fecha). Uso: node solo_n.js N "Objetivo 6,Objetivo 7" [pasta]
const { novo } = require('./carrega.js'); const N = +process.argv[2] || 100, ids = (process.argv[3] || '').split(',').filter(Boolean), pasta = process.argv[4] ? process.argv[4].replace(/\/?$/, '/') : undefined;
const J = novo(4242, pasta);
J.v(`function __jn(id, n, maxR, first) { const bots = Array(n).fill('normal'); A.new({ nomes: bots.map((_, i) => 'P' + i), bots, first });
  S.players[0].obj = { ...CARDS.objetivo.find(c => c.id === id) }; for (let i = 1; i < n; i++) S.players[i].obj = { id: 'Nunca', t: 'nunca' };
  Bot.chave = ''; Bot.erros = 0; let passos = 0; while (S && !S.win && S.round <= maxR && passos++ < 400000) Bot.acao();
  return { w: S.win ? S.players.findIndex(p => p.n === S.win.n) : -1, round: S.round, out: S.players[0].out, coins: S.players[0].coins, tot: S.players.reduce((a, p) => a + p.coins, 0) + S.gov, meta: vef(S.players[0].obj) }; }`);
const med = a => a.length ? a.slice().sort((x, y) => x - y)[Math.floor(a.length / 2)] : '-';
const OBJ = Object.fromEntries(J.v('CARDS.objetivo.map(o => [o.id, o.t])'));
console.log('objetivo     tipo         n  meta efet.  cumpriu  elim  semFim  rodada(med)  dinheiro total(med)');
for (const id of ids) for (const n of [2, 3, 4, 5]) { let ok = 0, el = 0, sf = 0; const ro = [], tt = []; let meta = 0;
  for (let g = 0; g < N; g++) { const r = J.v(`__jn(${JSON.stringify(id)}, ${n}, 150, ${g % n})`); meta = r.meta; if (r.w === 0) { ok++; ro.push(r.round); } else if (r.out) el++; else sf++; tt.push(r.tot); }
  console.log(`${id.padEnd(12)} ${OBJ[id].padEnd(11)} ${n} ${String(meta).padStart(10)} ${(100 * ok / N).toFixed(0).padStart(7)}% ${(100 * el / N).toFixed(0).padStart(4)}% ${(100 * sf / N).toFixed(0).padStart(6)}% ${String(med(ro)).padStart(11)} ${String(med(tt)).padStart(15)}`); }
