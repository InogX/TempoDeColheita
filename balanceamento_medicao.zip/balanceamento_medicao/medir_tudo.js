// ===== medir_tudo.js =====
// UM comando só:  node medir_tudo.js        (leva cerca de 1 minuto; os arquivos do jogo precisam estar nesta mesma pasta)
// Faz 3 coisas e explica cada resultado em português: (1) verificação de segurança, (2) partidas "de verdade" entre 2 bots, (3) cada objetivo medido sozinho.
const { spawnSync } = require('child_process'), fs = require('fs'), dir = __dirname + '/';
const JOGO = ['cartas.js', 'config.js', 'estado.js', 'cartas-visual.js', 'consultas.js', 'objetivos.js', 'rodada.js', 'acoes-turno.js', 'acoes-economia.js', 'acoes-plantio.js', 'acoes-mercado.js', 'comandos.js', 'bot.js', 'dev.js'];
const falta = JOGO.filter(f => !fs.existsSync(dir + f));
if (falta.length) { console.log('Faltam estes arquivos do jogo NESTA pasta:\n  ' + falta.join('\n  ') + '\n\nCopie os arquivos do jogo para a mesma pasta deste script e rode de novo.'); process.exit(2); }
const roda = (args) => spawnSync(process.execPath, args, { cwd: dir, stdio: 'inherit' }).status;
console.log('\n══════ 1/3  VERIFICAÇÃO DE SEGURANÇA ══════\nRoda centenas de partidas só de bots (2 a 10 jogadores) e confere os textos dos objetivos. O que você quer ver: "erros 0" em todas as linhas e "✓" no fim.\n');
const s1 = roda(['regressao.js']);
console.log('\n══════ 2/3  PARTIDAS DE VERDADE (2 bots, objetivos sorteados) ══════\nsorteado = quantas vezes o objetivo caiu para alguém; venceu = quantas vezes essa pessoa ganhou com ele; %venceu = venceu ÷ sorteado.\nO ideal é todos perto uns dos outros (um jogo equilibrado tem objetivos com chance parecida). Muito alto = fácil demais; muito baixo = difícil demais ou lento demais.\n');
roda(['medir.js', 'natural', '300']);
console.log('\n══════ 3/3  CADA OBJETIVO SOZINHO ══════\nO adversário recebe um objetivo que nunca fecha, para ver só a dificuldade do objetivo.\ncumpriu = % das partidas em que fechou; elim = % em que o jogador foi eliminado; semFim = % que passou de 150 rodadas sem fechar.\nrodada(mediana/p90) = em que rodada costuma fechar (metade das vezes até a mediana; 9 em 10 até o p90). Aqui o ideal é cumpriu ~100% e a mediana parecida entre os objetivos (por volta de 20).\nObjetivos desligados (minJ 99) ou de 6+ jogadores aparecem na lista mesmo assim, porque aqui eles são forçados.\n');
roda(['medir.js', 'solo', '100']);
console.log('\nPronto. Para o que significa cada linha, veja o LEIA-ME.md.'); process.exit(s1 ? 1 : 0);
