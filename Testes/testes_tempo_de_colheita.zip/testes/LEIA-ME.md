# Testes do Tempo de Colheita (pacote único)

Tudo o que é de **teste** do jogo online, num lugar só. **Nada disto vai para o GitHub Pages** e nada disto é necessário para jogar.

## Como rodar (eu rodo; você só guarda e envia)
1. Ponha **estes arquivos na MESMA pasta dos arquivos do jogo** (`online.js`, `rede.js`, `lobby.js`, `comandos.js`, `visao.js`...).
2. `node rodar_todos.js` → roda tudo (≈ 35 s) e mostra um ✅/❌ por teste.
   - `node rodar_todos.js --sem-regras` pula as repetições sob as regras (mais rápido).
   - `node rodar_todos.js --so=fase9` roda só os testes com "fase9" no nome.
3. Se faltar algum arquivo do jogo na pasta, o executor diz qual.

## O que tem aqui
| Arquivo | Para quê |
|---|---|
| `rodar_todos.js` | Executor único (o que você manda rodar). |
| `teste_comum.js` | Peças comuns: Firebase falso, aparelho, partida. Os outros dependem dele. |
| `teste_regras_motor.js` | Interpretador simplificado das regras do Firebase. `teste_regras.js` depende dele. |
| `teste_fase4.js` | Camada de comandos e bots (12 partidas de bots). |
| `teste_fase7.js` | Sincronização online, vez, recibos, privacidade da visão. |
| `teste_fase8.js` | Janelas online (Mercado, digitação, fora da vez, espiar). |
| `teste_fase9.js` | Robustez: quedas, bot assumindo, retomada do anfitrião, limpeza de salas. |
| `teste_fase10_sala8.js` | Sala de 8 vagas (anfitrião + convidado + 6 bots). |
| `teste_fase10_versao.js` | Número de versão e aviso de versão diferente. |
| `teste_regras.js` | 42 situações do tipo "Rules Playground" nas regras de segurança. |
| `regras_firebase.json` | As regras **publicadas** (cópia para os testes). **Se as regras mudarem no Firebase, atualize este arquivo.** |
| `regras_antigas.json` | Regras da fase anterior, só para o `teste_regras.js` mostrar "o que mudou". |

## Limites (o que estes testes NÃO provam)
- Usam o **Firebase falso** em memória e um interpretador **simplificado** das regras: a prova final das regras é o **Rules Playground** do console.
- `cartas.js`, `config.js`, `rodada.js`, `objetivos.js`, `cartas-visual.js` e `dev.js` são **peças falsas** dentro do `teste_comum.js`: os testes não conferem o balanceamento nem as cartas reais.
- Não testam celular de verdade (toque, teclado, iPhone), 4G/5G nem consumo real: isso é com o dono (ver `PLANOS_PENDENTES.md`).

## Quando mexer neste pacote
- Mudou um arquivo do jogo → rode `node rodar_todos.js`. Se um teste falhar por mudança **intencional**, o teste é que precisa ser atualizado (e a mudança dele deve ser dita).
- Mudou as regras do Firebase → atualize `regras_firebase.json` e o `teste_regras.js`.
- Ao enviar para uma conversa nova: este zip + os arquivos do jogo da etapa.
