// ===== rodar_todos.js =====
// Roda TODOS os testes do Tempo de Colheita (Node) e mostra um resumo. Uso, na pasta onde estão os arquivos do jogo E esta pasta de testes juntos:
//   node rodar_todos.js                 → tudo (cada teste normal + os do online de novo SOB as regras de segurança)
//   node rodar_todos.js --sem-regras    → pula as repetições sob as regras (mais rápido)
//   node rodar_todos.js --so=fase9      → só os testes cujo nome contém "fase9"
// Os testes usam os arquivos REAIS do jogo (online.js, rede.js, lobby.js...) lidos da MESMA pasta; cartas/config/rodada/objetivos são peças falsas dentro de teste_comum.js.
// Sai com código 0 se tudo passou, 1 se algum falhou, 2 se faltam arquivos.
const { spawnSync } = require('child_process'), fs = require('fs'), dir = __dirname + '/';
const JOGO = ['estado.js', 'consultas.js', 'acoes-turno.js', 'acoes-economia.js', 'acoes-plantio.js', 'acoes-mercado.js', 'comandos.js', 'bot.js', 'menu.js', 'lobby.js', 'pecas-tela.js', 'visao.js', 'janelas.js', 'tela.js', 'zoom.js', 'online.js', 'rede.js'];
const TESTES = ['teste_comum.js', 'teste_regras_motor.js', 'teste_fase4.js', 'teste_fase7.js', 'teste_fase8.js', 'teste_fase9.js', 'teste_fase10_sala8.js', 'teste_fase10_versao.js', 'teste_regras.js', 'regras_firebase.json', 'regras_antigas.json'];
const falta = JOGO.concat(TESTES).filter(f => !fs.existsSync(dir + f));
if (falta.length) { console.log('Faltam arquivos nesta pasta:\n  ' + falta.join('\n  ') + '\n(Os arquivos do jogo e os de teste precisam estar JUNTOS na mesma pasta.)'); process.exit(2); }
const args = process.argv.slice(2), semRegras = args.includes('--sem-regras'), so = (args.find(a => a.startsWith('--so=')) || '').slice(5);
const R = { REGRAS: 'regras_firebase.json' };
const lista = [
  ['Fase 4  — comandos e bots', 'teste_fase4.js', {}], ['Fase 7  — sincronização online', 'teste_fase7.js', {}], ['Fase 8  — janelas online', 'teste_fase8.js', {}], ['Fase 9  — robustez (quedas, retomada)', 'teste_fase9.js', {}],
  ['Fase 10 — sala de 8 vagas', 'teste_fase10_sala8.js', {}], ['Fase 10 — número de versão', 'teste_fase10_versao.js', {}], ['Regras de segurança (situações do Playground)', 'teste_regras.js', {}],
  ...(semRegras ? [] : [['Fase 7  — SOB as regras', 'teste_fase7.js', R], ['Fase 8  — SOB as regras', 'teste_fase8.js', R], ['Fase 9  — SOB as regras', 'teste_fase9.js', R], ['Fase 10 sala 8 — SOB as regras', 'teste_fase10_sala8.js', R], ['Fase 10 versão — SOB as regras', 'teste_fase10_versao.js', R]]),
].filter(t => !so || t[1].includes(so));
let ruins = 0; const t0 = Date.now(); console.log(`Rodando ${lista.length} teste(s)...\n`);
for (const [nome, arq, env] of lista) {
  const t = Date.now(), r = spawnSync(process.execPath, [dir + arq], { cwd: dir, env: { ...process.env, ...env }, encoding: 'utf8', timeout: 300000, maxBuffer: 64 * 1024 * 1024 });
  const saida = (r.stdout || '') + (r.stderr || ''), linhas = saida.split('\n'), resumo = (linhas.filter(l => l.startsWith('== ')).pop() || '(sem resumo)').replace(/^== | ==$/g, '');
  const ok = r.status === 0; if (!ok) ruins++;
  console.log(`${ok ? '✅' : '❌'} ${nome.padEnd(48)} ${resumo}  (${((Date.now() - t) / 1000).toFixed(1)} s)`);
  if (!ok) linhas.filter(l => /FALHOU|✗|ERRO|Error|timeout/i.test(l)).slice(0, 12).forEach(l => console.log('     ' + l.trim().slice(0, 200)));
}
console.log(`\n${ruins ? '❌ ' + ruins + ' teste(s) com falha' : '✅ TUDO PASSOU'} — ${((Date.now() - t0) / 1000).toFixed(0)} s no total.`);
process.exit(ruins ? 1 : 0);
